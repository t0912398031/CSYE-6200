package neu.edu.csye6200;

public abstract class AbstractItemAPI {

	public String info() {
		// TODO Auto-generated method stub
		return null;
	}

}
