package neu.edu.csye6200;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TwoAlternatingThreads.demo();
	}

}
