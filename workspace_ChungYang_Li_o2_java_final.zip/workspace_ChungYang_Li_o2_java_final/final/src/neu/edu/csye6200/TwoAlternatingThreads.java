package neu.edu.csye6200;

import java.util.ArrayList;
import java.util.List;

public class TwoAlternatingThreads {
	public static void demo() {
		Runnable r1 = () -> {
			List list = new ArrayList<>();
			list.add("a");
			list.add("b");
			list.add("c");
			list.add("d");
			list.add("e");
			list.add("f");
			list.add("g");
			list.add("i");
			list.add("j");
			list.add("k");
			list.add("l");
			list.add("m");
			list.add("n");
			list.add("o");
			list.add("p");
			list.add("q");
			list.add("r");
			list.add("s");
			list.add("t");
			list.add("u");
			list.add("v");
			list.add("w");
			list.add("x");
			list.add("y");
			list.add("z");
		
			for(int i=0;i<list.size();i++) {
				System.out.println(list.get(i));
//				Thread.sleep(1);
			}
		};
		
		Runnable r2 = () -> {
			List list = new ArrayList<>();
			list.add("A");
			list.add("B");
			list.add("C");
			list.add("D");
			list.add("E");
			list.add("F");
			list.add("G");
			list.add("H");
			list.add("I");
			list.add("J");
			list.add("K");
			list.add("L");
			list.add("M");
			list.add("N");
			list.add("O");
			list.add("P");
			list.add("Q");
			list.add("R");
			list.add("S");
			list.add("T");
			list.add("U");
			list.add("V");
			list.add("W");
			list.add("X");
			list.add("Y");
			list.add("Z");
			
			for(int i=0;i<list.size();i++) {
				System.out.println(list.get(i));
//				Thread.sleep(1);
			}
		};
		Thread t1 = new Thread(r1);
		Thread t2 = new Thread(r2);
		t1.start();
		t2.start();
	}
}
